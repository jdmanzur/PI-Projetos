Varias implementa��es est�o contidas nesse projeto, muitas delas fazem parte
dos testes realizados.

Para observar os resultados, basta executar a main.m. 
As imagens est�o na pasta /images, sendo que as originais possuem um nome
com um numero, e as editadas est�o na forma x-edited.jpg
Para testar outras imagens, basta trocar a imagem lida pelo programa na main.